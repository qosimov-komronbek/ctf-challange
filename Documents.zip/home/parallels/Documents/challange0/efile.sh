#!/bin/bash

# Define the Python file path
python_file="./.sourse/file.py"

# Execute the Python file and capture its output
output=$(python "$python_file")

# Print the output
echo "$output"


import os

def check_file_exists(path):
    directory = os.path.dirname(path)
    if not os.path.exists(directory):
        os.makedirs(directory)  # Create the directory if it doesn't exist
    if os.path.exists(path):
        print(f"I'm proud for you. Here is Your flag `HaadCTF:[dwe3rfetgregq]`")
    else:
        print(f"the file {path} not exists. Create it and run the command again")

# Example usage:
file_path = "/home/parallels/Documents/challange0/description.tx"
check_file_exists(file_path)

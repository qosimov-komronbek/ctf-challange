import os

def check_file_exists(path):
    directory = os.path.dirname(path)
    if not os.path.exists(directory):
        os.makedirs(directory)  # Create the directory if it doesn't exist
    if os.path.exists(path):
        print(f"I'm proud for you. Here is Your flag > HaadCTF{th!s_W@s_34sy_b3@zzY. @m_i_r!ght_0r_n0t}")
    else:
        print(f"the file /home/your_user/challenge04/{path} not exists. Create it and run the command again")

# Example usage:
file_path= "if/you/want/peace/prepare/for/war"
check_file_exists(file_path)
